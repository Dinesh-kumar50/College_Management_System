public class Placements {
    public void training_and_development(){
        System.out.println("The Placement Office gets the best of both national and international companies for recruitment to the campus and ensures smooth functioning of the placement process. Placement office has been consistently setting records for campus placements.\n" +
                "\n" +
                "The Placement Office undertakes the following activities:\n" +
                "\n" +
                "->Placement of students in industries through campus recruitments\n" +
                "->Internships and In-plant training for students across various industries\n" +
                "->Hosting contests, competitions and events\n" +
                "->Inviting corporate experts and industry leaders for guest lectures, seminars, interactions with students\n" +
                "->Establishing Industry-Academia collaboration\n" +
                "->Coordinating with Corporates to establish Centre of Excellence, Incubation Centre, R&D Centres and other initiatives\n" +
                "->Coordinating for Faculty Development Programmes with Corporate Sector\n" +
                "->Coordinating with Industry Oriented Electives");
        System.out.println("The Key Roles\n" +
                "The Placement Office enables the students to access a wide range of employment and lot of career avenues. The counseling provided by the placement office lets the students get an idea about them thereby helping to assess their own interests and skills as it allows them to pursue a job more professionally. The training provided for group discussions, resume building and interview skills help them to mould accordingly in order to fit into a prestigious career option. For any graduate program, the crowning factor will be the placement. Hence, AITS makes sure that all its pupils get a job offer not a mere but an opulent one.\n" +
                "\n" +
                "->To organize campus interviews for final year students with industries and business houses of repute from all over India.\n" +
                "->To prepare students to face campus interviews by training them in Aptitude tests, group discussions, preparing for Technical and HR interviews through professional trainers.\n" +
                "->To promote career counseling by organizing guidance lectures by senior corporate personnel and senior students.\n" +
                "->To organize campus interviews for final year students with industries and business houses of repute from all over India.\n" +
                "->To prepare students to face campus interviews by training them in Aptitude tests, group discussions, preparing for Technical and HR interviews through professional trainers\n" +
                "Sunil Alluvada\n" +
                "HOD Training & Placements\n" +
                "DM Group of Institutions\n" +
                " Tirupati |Hyderabad\n" +
                "Contact No. 9848022310 | 9848022338\n" +
                "Email: sunil.alluvada@dmagroup.org\n" +
                "\n" +
                "M. Lakshmi Narayana Reddy\n" +
                "Training & Placement Officer\n" +
                "DM Institute of Technology & Sciences\n" +
                "Tirupati\n" +
                "Contact No. 964456123\n" +
                "Email : placementsdmgrup@gmail.com");

    }
    public void training_programmes(){
        System.out.println("CAREER COUNSELLING ACTIVITIES \n" +
                "\n" +
                "We have conducted various activities through the academic year.\n" +
                "\n" +
                "The list of programs conducted by Placement Cell for Career Guidance is as follows,");
        System.out.println("->HR Guest Lecture\n->Cognizent Guest Lecture\n->Summer Internship\n->CIVIL CAD Workshop\n->Wipro Talent Next\n->IOT Internship\n->Virtual Reality\n->Q-Zap Internship\n->VM Ware Network Visualization\n->NI LabView\n->WOrkshop on TGMC Project\n->IBM Blue Mix Day\n->Industrialization Program\n->Artificial Intelligence Workshop ");
    }
    public void our_recruiters(){
        System.out.println("The Placement Companies(or Recruiters) are: ");
        System.out.println("->AMAZON\n->FLIPKART\n->ZOMATO\n->COGNIZANT\n->WIPRO\n->TCS\n->INFOSYS\n->CAP GEMINI\n->TECH MAHINDRA\n->CULTFIT\n->RED BUS\n->SWIGGY\n->MEESHO\n->GOOGLE");
    }

}
