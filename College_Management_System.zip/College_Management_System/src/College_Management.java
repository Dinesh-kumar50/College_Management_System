
import java.io.*;

import java.net.*;
import java.util.*;


public class College_Management {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("1.Departments\n 2.Admission cell \n 3. placement & training cell");
        System.out.println("Enter your choice:");
        int ch = sc.nextInt();
        switch (ch) {
            case 1:
                departments();
                break;
            case 2:
                admission_cell();
                break;

            case 3:
                placement_and_training_cell();
                break;
            default: System.out.println("INVALID OPTION");
        }

    }

    public static void departments() {
        Scanner sc1 = new Scanner(System.in);
        try {

            System.out.println("1.AI\n 2.CSE\n 3.ECE\n 4.MECH\n 5.CIVIL");
            int a = sc1.nextInt();
            switch (a) {
                case 1: {
                    System.out.println("The Head Of The Department for AI is Dr.K.Nawaz");
                    System.out.println("The no.of Faculties are 30\n It is a one of the department which is in very demand and highly paid packages will be available\n If you want more details you can visit our official college website ");
                    URL u1 = new URL("https://aits-tpt.edu.in/artificial-intelligence-and-data-science/");
                    System.out.println("for AI&DS" + u1.toString());
                }
                break;

                case 2: {
                    System.out.println("The Head Of The Department for CSE is Mr.Ramana Reddy\n The no.of faculties are 35\n It is one of the department for Software Engineers");
                    URL u2 = new URL("https://aits-tpt.edu.in/computers-science-engineering/");
                    System.out.println("for CSE  " + u2.toString());
                }
                break;

                case 3: {
                    System.out.println("The Head Of The Department for ECE is Pushpa Latha\n The no.of faculties are 25\n It is one of the department for Software Engineers");
                    URL u3 = new URL("https://aits-tpt.edu.in/electronics-and-communication-engineering-2/");
                    System.out.println("for ECE " + u3.toString());
                }
                break;

                case 4: {
                    System.out.println("The Head Of The Department for MECH is M.Balaji \n The no.of faculties are 25\n It is one of the department for Software Engineers");
                    URL u4 = new URL("https://aits-tpt.edu.in/mechanical-engineering/");
                    System.out.println("for MECH " + u4.toString());
                }
                break;

                case 5: {
                    System.out.println("The Head Of The Department for CIVIL is Dr.Guru Jawahar \n The no.of faculties are 25\n It is one of the department for Software Engineers");
                    URL u5 = new URL("https://aits-tpt.edu.in/civil-engineering/");
                    System.out.println("for CIVIL " + u5.toString());
                }
                break;
                default:
                    System.out.println("INVALID CHOICE");
                    break;


            }


        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void admission_cell() {
        Scanner sc2 = new Scanner(System.in);
        System.out.println("Enter your name");
        String name= sc2.nextLine();

        System.out.println("if you want to join from engineering entrance exam(type yes) or Management basis(type false) ");
        boolean b = sc2.nextBoolean();
        try {
            if (b == true) {
                System.out.println("Enter your rank");
                Double n = sc2.nextDouble();
                if (n <= 25000 && !(n <= 10000)) {
                    System.out.println("you are eligible for AI,MECH,CIVIL,ECE");
                    A a1=new A();
                    a1.s2();

                } else if (n <= 10000) {
                    System.out.println("you are elgigble for CSE,AI,MECH,CIVIL,ECE");
                    A a2=new A();
                    a2.s3();
                } else if (n >= 50000 && !(n >= 60000)) {
                    System.out.println("You are eligible for ECE,MECH,CIVIL");
                    A a3=new A();
                    a3.s4();
                } else {
                    System.out.println("You are eligible for only MECH and CIVIL");
                    A a4=new A();
                    a4.s5();
                }
            } else if (b == false) {
                System.out.println("On which department you want to join ");
                A a = new A();
                a.s1();
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    public static void placement_and_training_cell(){
        System.out.println("In training and placement cell there are 3 types of fields in it \n\n 1.Training and Development");
        Placements p=new Placements();
        p.training_and_development();
        System.out.println("2.Training Programmes");
        p.training_programmes();
        System.out.println("3.Our Recruiters");
        p.our_recruiters();

    }
}
