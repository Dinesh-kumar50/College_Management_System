

import java.util.*;
public class A {

    public static void s1(){
        Scanner sc=new Scanner(System.in);
        System.out.println("1.AI\n 2.CSE\n 3.ECE\n 4.MECH\n 5.CIVIL");
        int ch=sc.nextInt();
        switch (ch){
            case 1:
                System.out.println("Fee Structure of AI:");
                System.out.println("250000/-  Donation Fee of AI\n  150000/- per every year ");
                break;
            case 2:System.out.println("Fee Structure for CSE:\n 250000/- donation fee \n 175000/- pre every year");
                break;
            case 3:System.out.println("Fee Structure for ECE:\n 150000/- donation fee \n 100000/- pre every year");
                break;
            case 4:System.out.println("Fee Structure for MECH:\n 100000/- donation fee \n 75000/- pre every year");
                break;
            case 5:System.out.println("Fee Structure for CIVIL:\n 100000/- donation fee \n 75000/- pre every year");
                break;
            default:System.out.println("Invalid option");
        }
    }
    public static void s2() {
        Scanner sc = new Scanner(System.in);
        System.out.println("1.AI\n 2.ECE\n 3.MECH\n 4.CIVIL");
        int ch = sc.nextInt();
        try {
            switch (ch) {
                case 1:
                    System.out.println("Fee Structure of AI:");
                    System.out.println("  125000/- per every year ");
                    break;

                case 2:
                    System.out.println("Fee Structure for ECE:\n 750000/- pre every year");
                    break;
                case 3:
                    System.out.println("Fee Structure for MECH:\n 55000/- pre every year");
                    break;
                case 4:
                    System.out.println("Fee Structure for CIVIL:\n 55000/- pre every year");
                    break;

            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    public static void s3() {
        Scanner sc = new Scanner(System.in);
        System.out.println("1.AI\n 2.CSE\n 3.ECE\n 4.MECH\n 5.CIVIL");
        int ch = sc.nextInt();
        try {
            switch (ch) {
                case 1:
                    System.out.println("Fee Structure of AI:");
                    System.out.println("  125000/- per every year ");
                    break;
                case 2:System.out.println("Fee Structure for CSE:\n 150000/- pre every year");
                    break;
                case 3:
                    System.out.println("Fee Structure for ECE:\n 750000/- pre every year");
                    break;
                case 4:
                    System.out.println("Fee Structure for MECH:\n 55000/- pre every year");
                    break;
                case 5:
                    System.out.println("Fee Structure for CIVIL:\n 55000/- pre every year");
                    break;

            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    public static void s4() {
        Scanner sc = new Scanner(System.in);
        System.out.println("1.ECE\n 2.MECH\n 3.CIVIL");
        int ch = sc.nextInt();
        try {
            switch (ch) {


                case 1:
                    System.out.println("Fee Structure for ECE:\n 750000/- pre every year");
                    break;
                case 2:
                    System.out.println("Fee Structure for MECH:\n 55000/- pre every year");
                    break;
                case 3:
                    System.out.println("Fee Structure for CIVIL:\n 55000/- pre every year");
                    break;

            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public static void s5() {
        Scanner sc = new Scanner(System.in);
        System.out.println("1.MECH\n 2.CIVIL");
        int ch = sc.nextInt();
        try {
            switch (ch) {

                case 1:
                    System.out.println("Fee Structure for MECH:\n 55000/- pre every year");
                    break;
                case 2:
                    System.out.println("Fee Structure for CIVIL:\n 55000/- pre every year");
                    break;

            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
